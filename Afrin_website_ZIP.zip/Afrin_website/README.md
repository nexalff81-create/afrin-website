# Afrin Website ZIP

This is a small premium romantic surprise website for **Shifat ❤️ Afrin**.

## Files
- `index.html` → structure
- `style.css` → design and animations
- `script.js` → interactions
- `images/` → your photos
- `music/` → optional background song

## How to use on phone
1. Install **Acode** from Play Store.
2. Open the folder.
3. Paste the files exactly as they are.
4. Put your photos inside the `images/` folder.
5. If you want music, put a file named `love.mp3` inside `music/`.
6. Open `index.html` in preview or browser.

## How to use on PC
1. Create a folder named `Afrin_website`.
2. Add the files.
3. Open `index.html` in Chrome.

## How to make it live with a link
### GitHub Pages
1. Create a GitHub account.
2. Make a new repository.
3. Upload all files.
4. Go to **Settings → Pages**.
5. Select the `main` branch and root `/`.
6. Save.
7. After a minute, GitHub gives you a public link.

## How to customize later
Open `script.js` and edit:
- `nameA` and `nameB`
- `story`
- `gallery`
- `questions`
- `letter`

Open `style.css` and change:
- colors
- fonts
- spacing
- animation speed

## Music note
The website works without music too.
If you want music:
- add an mp3 file here: `music/love.mp3`

## What is already included
- loading screen
- floating hearts
- glassmorphism design
- photo gallery
- cute questions
- love letter
- final surprise
- mobile friendly layout

Enjoy the surprise ❤️
