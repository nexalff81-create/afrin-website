const CONFIG = {
  nameA: "Shifat",
  nameB: "Afrin",
  heroText: "Tomake niye amar chhoto ekta beautiful surprise ✨",
  story: [
    "Tomake peye amar life onek beautiful hoye geche.",
    "Every moment with you feels special, calm, and bright.",
    "Jibon-e onek kichu change hoy, but sweet memories stay forever.",
    "Ami chai amader shob chhoto moments-o beautiful hoye thakuk ❤️"
  ],
  gallery: [
    { src: "images/1.png", caption: "A memory frame from the game vibes ✨" },
    { src: "images/2.jpg", caption: "Another soft moment captured beautifully 💫" },
    { src: "images/3.jpg", caption: "A little glow, a little story, a little us ❤️" }
  ],
  questions: [
    {
      q: "Do you enjoy spending time with me?",
      options: ["Yes ❤️", "Of course ❤️"],
      good: "Yay, that made me smile 😌❤️"
    },
    {
      q: "Will you stay beside me in sweet memories?",
      options: ["Always ❤️", "Forever ❤️"],
      good: "That means a lot to me ✨"
    },
    {
      q: "Can I keep making you smile?",
      options: ["Yes ❤️", "Try your best 😄"],
      good: "I’ll do my best every day 🌷"
    }
  ],
  letter: `Afrin,\n\nTomake niye ei chhoto website ta banano — just because you deserve something soft, sweet, and special.\n\nTumi jokhon hasho, tokhon shob kichu aro light hoye jay.\nAmi chai amader shob chhoto moment gulao beautiful memory hoye thakuk.\n\nThis is not huge, but it is made with care.\nAnd that matters to me.\n\nShifat ❤️`,
  finalText: "Thank you Afrin ❤️"
};

const els = {
  loading: document.getElementById("loading"),
  app: document.getElementById("app"),
  overlay: document.getElementById("overlay"),
  heroText: document.getElementById("heroText"),
  story: document.getElementById("typewriter"),
  galleryImg: document.getElementById("galleryImg"),
  galleryCaption: document.getElementById("galleryCaption"),
  photoDots: document.getElementById("photoDots"),
  questionStep: document.getElementById("questionStep"),
  questionText: document.getElementById("questionText"),
  choices: document.getElementById("choices"),
  questionNote: document.getElementById("questionNote"),
  letterText: document.getElementById("letterText"),
  startBtn: document.getElementById("startBtn"),
  scrollBtn: document.getElementById("scrollBtn"),
  prevPhoto: document.getElementById("prevPhoto"),
  nextPhoto: document.getElementById("nextPhoto"),
  fireBtn: document.getElementById("fireBtn"),
  musicBtn: document.getElementById("musicBtn"),
  themeBtn: document.getElementById("themeBtn"),
  bgMusic: document.getElementById("bgMusic")
};

let photoIndex = 0;
let questionIndex = 0;
let musicEnabled = false;
let questionLocked = false;

function wait(ms){ return new Promise(res => setTimeout(res, ms)); }

function typeWriter(el, text, speed = 30){
  el.textContent = "";
  let i = 0;
  const tick = () => {
    if(i <= text.length){
      el.textContent = text.slice(0, i++);
      setTimeout(tick, speed);
    }
  };
  tick();
}

function showApp(){
  els.loading.style.opacity = "0";
  setTimeout(() => {
    els.loading.classList.add("hidden");
    els.app.classList.remove("hidden");
    revealElements();
    startFloatingHearts();
    startStory();
    initGallery();
    renderQuestion();
    els.letterText.textContent = CONFIG.letter;
    revealSoon();
  }, 650);
}

function revealSoon(){
  setTimeout(() => {
    document.querySelectorAll(".reveal").forEach((sec, idx) => {
      setTimeout(() => sec.classList.add("visible"), idx * 130);
    });
  }, 220);
}

function revealElements(){
  // force first sections visible in case of reduced motion
  document.querySelectorAll(".reveal").forEach(sec => sec.classList.add("visible"));
}

function startStory(){
  let idx = 0;
  const lines = CONFIG.story.map(s => `• ${s}`).join("\n\n");
  typeWriter(els.story, lines, 24);
}

function initGallery(){
  renderGallery();
  renderDots();
}

function renderGallery(){
  const item = CONFIG.gallery[photoIndex];
  els.galleryImg.style.opacity = "0";
  setTimeout(() => {
    els.galleryImg.src = item.src;
    els.galleryCaption.textContent = item.caption;
    els.galleryImg.style.opacity = "1";
  }, 180);
  [...els.photoDots.children].forEach((dot, i) => {
    dot.classList.toggle("active", i === photoIndex);
  });
}

function renderDots(){
  els.photoDots.innerHTML = "";
  CONFIG.gallery.forEach((_, i) => {
    const dot = document.createElement("button");
    dot.className = "dot" + (i === photoIndex ? " active" : "");
    dot.type = "button";
    dot.addEventListener("click", () => {
      photoIndex = i;
      renderGallery();
    });
    els.photoDots.appendChild(dot);
  });
}

function nextPhoto(){
  photoIndex = (photoIndex + 1) % CONFIG.gallery.length;
  renderGallery();
}

function prevPhoto(){
  photoIndex = (photoIndex - 1 + CONFIG.gallery.length) % CONFIG.gallery.length;
  renderGallery();
}

function renderQuestion(){
  const q = CONFIG.questions[questionIndex];
  els.questionStep.textContent = `Question ${questionIndex + 1} of ${CONFIG.questions.length}`;
  els.questionText.textContent = q.q;
  els.choices.innerHTML = "";
  q.options.forEach((opt, idx) => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "choice" + (idx === 0 ? " good" : "");
    btn.textContent = opt;
    btn.addEventListener("click", () => answerQuestion(opt));
    els.choices.appendChild(btn);
  });
  els.questionNote.textContent = "Choose one sweet answer ❤️";
}

function answerQuestion(answer){
  if(questionLocked) return;
  questionLocked = true;
  const q = CONFIG.questions[questionIndex];
  els.questionNote.textContent = `${q.good} — you picked: ${answer}`;
  burstHearts(8);
  setTimeout(() => {
    questionIndex = Math.min(questionIndex + 1, CONFIG.questions.length - 1);
    if(questionIndex < CONFIG.questions.length - 1 || questionIndex === CONFIG.questions.length - 1){
      renderQuestion();
      els.questionNote.textContent = "Another cute question is ready ❤️";
    }
    questionLocked = false;
  }, 1000);
}

function randomBetween(min, max){
  return Math.random() * (max - min) + min;
}

function createHeart(){
  const heart = document.createElement("div");
  heart.className = "heart";
  heart.textContent = Math.random() > 0.5 ? "❤️" : "💗";
  heart.style.left = randomBetween(2, 98) + "vw";
  heart.style.bottom = "-24px";
  heart.style.fontSize = randomBetween(14, 30) + "px";
  heart.style.animationDuration = randomBetween(6, 11) + "s";
  heart.style.opacity = randomBetween(.6, 1);
  els.overlay.appendChild(heart);
  setTimeout(() => heart.remove(), 11500);
}

function burstHearts(count = 14){
  for(let i=0;i<count;i++){
    const heart = document.createElement("div");
    heart.className = "heart";
    heart.textContent = ["❤️","💖","✨","🌸"][Math.floor(Math.random()*4)];
    heart.style.left = randomBetween(15, 85) + "vw";
    heart.style.top = randomBetween(25, 75) + "vh";
    heart.style.animationDuration = randomBetween(2.8, 4.2) + "s";
    heart.style.fontSize = randomBetween(18, 34) + "px";
    els.overlay.appendChild(heart);
    setTimeout(() => heart.remove(), 4600);
  }
}

function confettiRain(count = 24){
  for(let i=0;i<count;i++){
    const c = document.createElement("div");
    c.className = "confetti";
    c.textContent = ["✨","💗","🌷","⭐","❤️"][Math.floor(Math.random()*5)];
    c.style.left = randomBetween(0, 100) + "vw";
    c.style.animationDuration = randomBetween(2.8, 5.2) + "s";
    c.style.fontSize = randomBetween(12, 20) + "px";
    els.overlay.appendChild(c);
    setTimeout(() => c.remove(), 5600);
  }
}

function startFloatingHearts(){
  setInterval(createHeart, 900);
}

function smoothScrollTo(id){
  document.querySelector(id)?.scrollIntoView({behavior:"smooth", block:"start"});
}

function setThemeMode(){
  document.body.classList.toggle("light");
  els.themeBtn.textContent = document.body.classList.contains("light") ? "Light Glow" : "Dark Glow";
}

function toggleMusic(){
  musicEnabled = !musicEnabled;
  if(musicEnabled){
    const playPromise = els.bgMusic.play();
    if(playPromise && typeof playPromise.catch === "function"){
      playPromise.catch(() => {
        musicEnabled = false;
        els.musicBtn.textContent = "Music Off";
        alert("music/love.mp3 file add korle music chalu hobe.");
      });
    }
    els.musicBtn.textContent = "Music On";
  }else{
    els.bgMusic.pause();
    els.musicBtn.textContent = "Music Off";
  }
}

function init(){
  setTimeout(showApp, 1800);

  els.startBtn.addEventListener("click", () => smoothScrollTo("#story"));
  els.scrollBtn.addEventListener("click", () => smoothScrollTo("#gallery"));
  els.prevPhoto.addEventListener("click", prevPhoto);
  els.nextPhoto.addEventListener("click", nextPhoto);
  els.fireBtn.addEventListener("click", () => { burstHearts(18); confettiRain(26); });
  els.musicBtn.addEventListener("click", toggleMusic);
  els.themeBtn.addEventListener("click", setThemeMode);

  setInterval(nextPhoto, 4200);

  document.addEventListener("keydown", (e) => {
    if(e.key === "ArrowRight") nextPhoto();
    if(e.key === "ArrowLeft") prevPhoto();
  });
}

init();
